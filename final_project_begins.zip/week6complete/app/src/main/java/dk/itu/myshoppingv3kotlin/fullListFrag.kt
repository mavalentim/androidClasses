package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.runBlocking

class fullListFrag:Fragment(){
    private lateinit var itemsDB: ItemsDB

    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)

        //initialize the items we have available
        itemsDB = ItemsDB.get()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(
            R.layout.adding,
            container,
            false
        )
        //add all the functionality: now using viewmodel -> we inflate the layout, from the layout we get the place to be filled
        //but we connect to the viewmodel to fill it, its all through the viewmodel

        //val text:TextView = searchView.findViewById(R.id.tobefilled)


        val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]


        val goAheadButton :Button = searchView.findViewById(R.id.addbutton)
        //here we observe the field uiState, and every time we change it, we change the textView "text"
        goAheadButton.setOnClickListener{
            runBlocking {
                val response = viewModel.onAnswerClick()
                response?.let {
                    // Handle successful response
                    Log.v("heh", response)
                } ?: run {
                    // Handle error
                    println("Error occurred while making the GET request")
                }
            }

        }



        //text.text = itemsDB.listItems()

        return searchView
    }
    }