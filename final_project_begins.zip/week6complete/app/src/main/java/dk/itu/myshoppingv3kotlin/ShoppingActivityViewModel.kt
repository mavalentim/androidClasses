package dk.itu.myshoppingv3kotlin

import android.graphics.Color
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

suspend fun makeGetRequest(urlString: String):String {
    var connection: HttpURLConnection? = null
    try {
        val url = URL(urlString)
        connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"

        val inputStream = connection.inputStream
        val reader = BufferedReader(InputStreamReader(inputStream))
        val response = StringBuilder()
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            response.append(line)
        }
        reader.close()

        val jsonResponse = response.toString()
        return jsonResponse

    } catch (e: IOException) {
        e.printStackTrace()
    } finally {
        connection?.disconnect()
    }
    return ""
}


class ShoppingActivityViewModel: ViewModel() {


    val uiState: MutableLiveData<CurrentAppState> = MutableLiveData<CurrentAppState>(CurrentAppState(
        "",
        "",
        "",
        "",
        0,
        1
    ))


    //there needs to be a deleting functionality
    suspend fun onAnswerClick(): String { //country: TextView, year:TextView
        //val guessedCountry = country.text.toString().trim { it <= ' ' }
        //val guessedYear = year.text.toString().trim { it <= ' ' }
        return makeGetRequest("https://collectionapi.metmuseum.org/public/collection/v1/objects/199905")

        //call the api to get the next one

    }

    //shoppingUiState is a data class
    data class CurrentAppState(
        val correctCountry: String,
        val guessedCountry: String,
        val correctYear : String,
        val guessedYear : String,
        val correctOnes: Int,
        val whichOneTheyAt :Int
    )
}