package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.runBlocking

//this is the part of the fragment that has a next one button and a place for the user to guess the stuff
class fullListFrag:Fragment(){
    private lateinit var itemsDB: ItemsDB

    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(
            R.layout.adding,
            container,
            false
        )


        //getting the viewModel
        val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]

        //


        val goAheadButton :Button = searchView.findViewById(R.id.addbutton)
        //here we observe the field uiState, and every time we change it, we change the textView "text"
        goAheadButton.setOnClickListener{
            val countryButton:TextView = searchView.findViewById(R.id.textInputEditText)
            val yearButton:TextView = searchView.findViewById(R.id.textInputEditText2)

            viewModel.onAnswerClick(countryButton, yearButton, goAheadButton)
        }


        return searchView
    }
    }