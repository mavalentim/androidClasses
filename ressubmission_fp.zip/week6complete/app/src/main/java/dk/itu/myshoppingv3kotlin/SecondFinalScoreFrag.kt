package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SecondFinalScoreFrag :Fragment(){


    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(
            R.layout.second_final_score,
            container,
            false
        )

        //button that goes back to the previous screen
        val goback: Button = searchView.findViewById(R.id.button2)

        goback.setOnClickListener{
            Navigation.findNavController(it).navigate(R.id.action_secondFinalScoreFrag_to_firstFinalScoreFrag)
        }

        val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]

        val goFullback: Button = searchView.findViewById(R.id.button23)

        goFullback.setOnClickListener{
            viewModel.userTurn.value = 0
            Navigation.findNavController(it).navigate(R.id.action_secondFinalScoreFrag_to_shoppingActivity)
        }

        //getting the data from the viewmodel



        //getting the recyclerView

        val recyclerView : RecyclerView = searchView.findViewById(R.id.recyclerView)

        //once we create the recycler view here we need a few things for every recycler view
        //we need a layout manager
        recyclerView.layoutManager = LinearLayoutManager(activity)

        //we need an itemAdapter, which on its own need an ItemHolder
        val mAdapter = ItemAdapter()
        recyclerView.adapter = mAdapter



        return searchView
    }




    private inner class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val mWhatTextView: TextView //the fields of this class are boxes to be filled, that get filled with the bind function call
        private val mWhereTextView: TextView
        private val mNoView: TextView

        init {
            mWhatTextView = itemView.findViewById(R.id.countryblank)
            mWhereTextView = itemView.findViewById(R.id.yearblank)
            mNoView= itemView.findViewById(R.id.numberblank)
        }

        fun bind(country: String, year:String, position: Int) { //this function just fills in the located views which are the fields
            mWhatTextView.text = country
            mWhereTextView.text = year
            mNoView.text= " $position "
        }
    }

    private inner class ItemAdapter : RecyclerView.Adapter<ItemHolder>() {
        val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
                ItemHolder {
            val layoutInflater= LayoutInflater.from(activity)
            val v= layoutInflater.inflate(R.layout.onerow, parent, false)
            return ItemHolder(v)
        }
        override fun onBindViewHolder(holder: ItemHolder, position: Int) {
            val country = viewModel.guessesForCountries[position]
            val year = viewModel.guessesForYears[position]
            holder.bind(country, year, position)
        }
        override fun getItemCount(): Int {
            return viewModel.guessesForCountries.size
        }
    }

}








