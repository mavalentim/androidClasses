package dk.itu.myshoppingv3kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment


class ShoppingActivity : Fragment() {
    // Model: Database of items
    //private lateinit var itemsDB: ItemsDB

    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(R.layout.shopping, container, false)



        //this is a special object that is capable of filling frames in the content view I set
        val fm: FragmentManager = parentFragmentManager

        //When user is done, navigate to last page

        //do do the navigation
        //val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment_container) as NavHostFragment

        //val navController = navHostFragment.navController

        //to know when user is done



        //so we access the fragment via the class we defined for it
        //fragments are not hollow, they have internal functioning
        val frag1:Fragment = SearchFrag()

        //we also through the fragment manager create a transaction with the special method beginTransaction
        var fragtrans : FragmentTransaction = fm.beginTransaction()

        //we add the transaction that we want
        fragtrans.add(R.id.framefs, frag1)
        fragtrans.commit()


        val frag2:Fragment = fullListFrag()
        fm.beginTransaction().add(R.id.frameflist, frag2).commit()
        //displayButton.setOnClickListener{}

        //if we are in the landscape case however, we need to automatically transact the fragment into the frame, so if we are in that landscape mode, i will automatically fill that frame with the fragment



    return searchView


    }
}