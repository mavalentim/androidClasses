package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider

class SearchFrag: Fragment() {



    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(R.layout.searchfrag, container, false) //THIS CREATES A VIEW OUT OF THE LAYOUT DEFINITION

        //getting the viewModel to track user progress
        val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]

        //GOTTA GET THE WEBVIEW TO TRY IT OUT
        val myWebView: WebView = searchView.findViewById(R.id.webView)

        viewModel.fillWebView(myWebView)


        viewModel.userTurn.observe(viewLifecycleOwner){
            viewModel.fillWebView(myWebView)
        }



        return searchView
    }
}