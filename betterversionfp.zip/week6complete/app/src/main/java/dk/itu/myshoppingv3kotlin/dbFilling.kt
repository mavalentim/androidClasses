package dk.itu.myshoppingv3kotlin

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import android.widget.TextView

fun dbFilling(db: SQLiteDatabase) {
    db.execSQL("INSERT INTO Items (what, whereC, whenC) VALUES ('https://images.metmuseum.org/CRDImages/ao/web-large/DP18638.jpg', 'Peru', '800')") //objectid 199905
    db.execSQL("INSERT INTO Items (what, whereC, whenC) VALUES ('https://images.metmuseum.org/CRDImages/ad/web-large/181517.jpg', 'United States', '1800')") //
    db.execSQL("INSERT INTO Items (what, whereC, whenC) VALUES ('https://images.metmuseum.org/CRDImages/as/web-large/DP136956.jpg', 'Japan', '1790')") //
    db.execSQL("INSERT INTO Items (what, whereC, whenC) VALUES ('https://images.metmuseum.org/CRDImages/ad/web-large/LC-83_2_206-001.jpg', 'France', '1883')")

    //https://images.metmuseum.org/CRDImages/es/web-large/146484.jpg
    //https://images.metmuseum.org/CRDImages/as/web-large/DP136956.jpg
    //db.execSQL("DELETE FROM Items")
    /*
    db.execSQL("INSERT INTO Items (what, whereC) VALUES ('milk', 'netto')")
    db.execSQL("INSERT INTO Items (what, whereC) VALUES ('milk', 'netto')")
    db.execSQL("INSERT INTO Items (what, whereC) VALUES ('milk', 'netto')")
    db.execSQL("INSERT INTO Items (what, whereC) VALUES ('milk', 'netto')")
    db.execSQL("INSERT INTO Items (what, whereC) VALUES ('milk', 'netto')")


     */

    val cursor = db.query("Items", null, null, null, null, null, null)
    cursor.moveToFirst()
    while (!cursor.isAfterLast) {
        Log.i("myTAG", cursor.getString(0))
        Log.i("myTAG", cursor.getString(1))
        Log.i("myTAG", cursor.getString(2))
        cursor.moveToNext()
    }
    Log.i("myTAG2", "END OF THE DB")
    cursor.close()
}