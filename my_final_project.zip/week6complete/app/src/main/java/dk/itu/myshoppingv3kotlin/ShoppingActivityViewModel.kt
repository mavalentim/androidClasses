package dk.itu.myshoppingv3kotlin

import android.app.Application
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.navigation.Navigation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL




class ShoppingActivityViewModel(application: Application) : AndroidViewModel(application) {
    private val mDatabase: SQLiteDatabase
    val userTurn: MutableLiveData<Int> = MutableLiveData(0)
    val countriesRight: MutableLiveData<Int> = MutableLiveData(0)
    val yearsRight: MutableLiveData<Int> = MutableLiveData(0)
    val myapplication: Context =application.applicationContext
    val guessesForCountries: ArrayList<String> = ArrayList()
    val guessesForYears: ArrayList<String> = ArrayList()
    init {
        mDatabase = SimpleSQL(application.applicationContext).writableDatabase
        //val a = application.applicationContext
        //dbFilling(mDatabase)
         //here we fill it with urls, country name and year, so that we only hold which one they are in
    }

    /*
    val uiState: MutableLiveData<CurrentAppState> = MutableLiveData<CurrentAppState>(CurrentAppState(
        "",
        "",
        "",
        "",
        0,
        1
    ))


     */




    //function to get an url to put it in the webview
    fun fillWebView(webView: WebView) {
        val cursor = mDatabase.query("Items", null, null, null, null, null, null)
        //if(userTurn.value != null){
        userTurn.value?.let { cursor.moveToPosition(it) }

        //the cursor should be in the position of the userTurn variable, so we get the values
        val url = cursor.getString(0)
        val country = cursor.getString(1)
        val year = cursor.getString(2)

        //and we fill the webView with those values
        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true

        //this creates a runnable R from the class HttpThread, this will RUN that runnable outside the main thread

        webView.loadUrl(url)

        cursor.close()
    }




    fun onAnswerClick(country: TextView, year:TextView, answerButton: Button) {
        val cursor = mDatabase.query("Items", null, null, null, null, null, null)
        //if(userTurn.value != null){
        userTurn.value?.let { cursor.moveToPosition(it) }

        //the cursor should be in the position of the userTurn variable, so we get the values
        val trueCountry = cursor.getString(1)
        val trueYear = cursor.getString(2)

        val guessedCountry = country.text.toString().trim { it <= ' ' }
        val guessedYear = year.text.toString().trim { it <= ' ' }
        //return makeGetRequest("https://collectionapi.metmuseum.org/public/collection/v1/objects/199905")

        //guessed the right country gets a plus one
        if(guessedYear.equals(trueYear)){
            yearsRight.value = yearsRight.value!! + 1
        }

        //guessed the right year gets a plus one
        if(guessedCountry.equals(trueCountry)){
            countriesRight.value = countriesRight.value!! + 1
        }

        //add guesses to the map, to be displayed in last page
        guessesForCountries.add(guessedCountry)
        guessesForYears.add(guessedYear)


        //change the shared value with the shared view
        if(userTurn.value!! < 3){
            userTurn.value = userTurn.value?.let{it+1}
            Log.i("RELEVANT SHIT", countriesRight.value.toString())
        } else{
            Navigation.findNavController(answerButton).navigate(R.id.action_shoppingActivity_to_firstFinalScoreFrag)
        }

    }




    //shoppingUiState is a data class
    data class CurrentAppState(
        val correctCountry: String,
        val guessedCountry: String,
        val correctYear : String,
        val guessedYear : String,
        val correctOnes: Int,
        val whichOneTheyAt :Int
    )
}