package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation


class FirstFinalScoreFrag: Fragment(){


    override fun onCreate(savedInstanceState: Bundle?) { //initialization of the fragment things should run here
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View { //THIS FUNCTION HAS TO RETURN A VIEW
        val searchView: View = inflater.inflate(
            R.layout.final_score,
            container,
            false
        )


        //getting the viewModel
        //val viewModel = ViewModelProvider(requireActivity())[ShoppingActivityViewModel::class.java]

        //displaying the child fragments inside of this one
        //this is a special object that is capable of filling frames in the content view I set
        val fm: FragmentManager = parentFragmentManager

        //var fragtrans : FragmentTransaction = fm.beginTransaction()

        //one fragment for displaying the country score
        val frag1: Fragment = countriesScoreFrag()

        //we also through the fragment manager create a transaction with the special method beginTransaction
        var fragtrans : FragmentTransaction = fm.beginTransaction()

        //we add the transaction that we want
        fragtrans.add(R.id.framefs1, frag1)
        fragtrans.commit()


        val frag2: Fragment = yearScoreFrag()
        fm.beginTransaction().add(R.id.framefs2, frag2).commit()


        //navigation part
        val nextButton: Button = searchView.findViewById(R.id.button)
        nextButton.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_firstFinalScoreFrag_to_secondFinalScoreFrag)
        }


        return searchView
    }
}