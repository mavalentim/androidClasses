package dk.itu.myshoppingv3kotlin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class FinalPageActivity : AppCompatActivity() {
    // Model: Database of items
    //private lateinit var itemsDB: ItemsDB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.outter_final_score)



        //displayButton.setOnClickListener{}

        //if we are in the landscape case however, we need to automatically transact the fragment into the frame, so if we are in that landscape mode, i will automatically fill that frame with the fragment




    }
}